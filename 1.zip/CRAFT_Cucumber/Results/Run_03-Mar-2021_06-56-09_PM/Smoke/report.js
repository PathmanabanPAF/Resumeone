$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Login2.feature");
formatter.feature({
  "line": 1,
  "name": "Login",
  "description": "As a user, I want to login demo site\r\nwhen I present valid credentials for demo site",
  "id": "login",
  "keyword": "Feature"
});
formatter.before({
  "duration": 7859868900,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "I am in the login page of the application",
  "keyword": "Given "
});
formatter.match({
  "location": "GeneralStepDefs.i_am_in_login_page()"
});
formatter.embedding("image/png", "embedded0.png");
formatter.result({
  "duration": 3563864000,
  "error_message": "java.lang.AssertionError: expected [true] but found [false]\r\n\tat org.testng.Assert.fail(Assert.java:93)\r\n\tat org.testng.Assert.failNotEquals(Assert.java:512)\r\n\tat org.testng.Assert.assertTrue(Assert.java:41)\r\n\tat org.testng.Assert.assertTrue(Assert.java:51)\r\n\tat com.CucumberCraft.stepDefinitions.GeneralStepDefs.i_am_in_login_page(GeneralStepDefs.java:25)\r\n\tat ✽.Given I am in the login page of the application(Login2.feature:6)\r\n",
  "status": "failed"
});
formatter.scenario({
  "line": 9,
  "name": "Login with demo site",
  "description": "",
  "id": "login;login-with-demo-site",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 8,
      "name": "@sample"
    }
  ]
});
formatter.step({
  "line": 10,
  "name": "I login using demo site",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "The application should login demo site",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.after({
  "duration": 1593307000,
  "status": "passed"
});
});