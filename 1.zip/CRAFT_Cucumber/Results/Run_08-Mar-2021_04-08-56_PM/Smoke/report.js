$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Login2.feature");
formatter.feature({
  "line": 1,
  "name": "Login",
  "description": "As a user, I want to login demo site\r\nwhen I present valid credentials for demo site",
  "id": "login",
  "keyword": "Feature"
});
formatter.before({
  "duration": 9144144800,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "I am in the login page of demo site",
  "keyword": "Given "
});
formatter.match({
  "location": "Demosite.i_am_in_the_login_page_of_demo_site()"
});
formatter.result({
  "duration": 2480240100,
  "status": "passed"
});
formatter.scenario({
  "line": 9,
  "name": "Login with demo site",
  "description": "",
  "id": "login;login-with-demo-site",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 8,
      "name": "@sample"
    }
  ]
});
formatter.step({
  "line": 10,
  "name": "I login using demo site",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "The application should login demo site",
  "keyword": "Then "
});
formatter.match({
  "location": "Demosite.i_login_using_demo_site()"
});
formatter.result({
  "duration": 15238711100,
  "status": "passed"
});
formatter.match({
  "location": "Demosite.the_application_should_login_demo_site()"
});
formatter.result({
  "duration": 62600,
  "status": "passed"
});
formatter.after({
  "duration": 1755382700,
  "status": "passed"
});
});