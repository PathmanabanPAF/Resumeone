package com.CucumberCraft.stepDefinitions;

import static org.testng.Assert.assertTrue;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Listeners;

import com.CucumberCraft.supportLibraries.DriverManager;
import com.CucumberCraft.supportLibraries.Util;

import atu.testng.reports.ATUReports;
import atu.testng.reports.listeners.ATUReportsListener;
import atu.testng.reports.listeners.ConfigurationListener;
import atu.testng.reports.listeners.MethodListener;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import ru.yandex.qatools.allure.Allure;
@Listeners({ ATUReportsListener.class, ConfigurationListener.class,
    MethodListener.class })
public class Demosite {
	// Logger log = Logger.getLogger(LoginStepDefs.class);
	//WebDriver driver = DriverManager.getWebDriver();
	WebDriver driver;
	
	@Given("^I am in the login page of demo site$")
	public void i_am_in_the_login_page_of_demo_site() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.setProperty("webdriver.chrome.driver", "C:\\Javalibs\\Selenium\\Browser Drivers\\chromedriver.exe");
		driver=new ChromeDriver();
		System.setProperty("atu.reporter.config","C:\\Users\\660763\\Downloads\\PEGA\\PAF_QA\\Automation\\PAF\\PAF_Workspace\\PAF_Library\\atu.properties");
	driver.get("https://www.seleniumeasy.com/test/basic-first-form-demo.html");
		
	ATUReports.currentRunDescription = "URL Launched successfully";
	
			}

	@When("^I login using demo site$")
	public void i_login_using_demo_site() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id='at-cv-lightbox-close']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"user-message\"]")).sendKeys("TEST");
		Thread.sleep(5000);

	
		
	}

	@Then("^The application should login demo site$")
	public void the_application_should_login_demo_site() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		driver.close();
	}
	
}
