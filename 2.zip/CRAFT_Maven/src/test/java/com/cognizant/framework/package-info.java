/**
 * Package containing reusable libraries which are common across Cognizant's CRAFT and CRAFTLite Frameworks, and applicable to any automation tool based on Java
 * @author Cognizant
 */
package com.cognizant.framework;