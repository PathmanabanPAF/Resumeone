package pageObjects;

import org.openqa.selenium.By;

/**
 * UI Map for SelectFlightPage 
 */
public class SelectFlightPage {
	// Buttons
	public static final By btnContinue = By.name("reserveFlights");
}