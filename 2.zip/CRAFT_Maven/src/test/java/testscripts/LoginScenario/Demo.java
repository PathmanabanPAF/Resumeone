package testscripts.LoginScenario;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.cognizant.Craft.CRAFTTestCase;
import com.cognizant.Craft.DriverScript;
import com.cognizant.framework.IterationOptions;
import com.cognizant.framework.selenium.Browser;
import com.cognizant.framework.selenium.ExecutionMode;
import com.cognizant.framework.selenium.SeleniumTestParameters;

import atu.testng.reports.ATUReports;




/**
 * Test for login with valid user credentials
 * 
 * @author Cognizant
 */
public class Demo {

	@Test()
	public void test1() throws InterruptedException {
		
		
		System.setProperty("atu.reporter.config","C:\\Users\\660763\\Downloads\\PEGA\\PAF_QA\\Automation\\PAF\\PAF_Workspace\\PAF_Library\\atu.properties");
		WebDriver driver;
	    System.setProperty("webdriver.chrome.driver", "C:\\Javalibs\\Selenium\\Browser Drivers\\chromedriver.exe");
		driver=new ChromeDriver();
		Thread.sleep(6000);
		ATUReports.currentRunDescription = "URL Launched successfully";
		driver.get("https://www.google.co.in");
		Thread.sleep(6000);
		driver.close();
		
	}

}