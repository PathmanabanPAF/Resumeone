 import static org.junit.Assert.assertEquals;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class RoleJUnit {
	RoleBO roleBO;
	
	@Before
	public void createObjectForRoleBO() {
		//fill the code
		roleBO = new RoleBO();
	}
	
	@Rule
	public ExpectedException exception = ExpectedException.none();
	
	@Test
	public void testIsRolePresent() throws InvalidRoleException {
		//fill the code
		exception.expect(InvalidRoleException.class);
		roleBO.isRolePresent(1, "Test", 40);
		
	}
	
	@Test
	public void testIsRolePresent_Exception() throws InvalidRoleException {
		//fill the code
		//assertEquals(roleBO.isRolePresent(1, "Test", 10), new User(1, "Test", Role.role[0]));
		Assert.assertTrue(EqualsBuilder.reflectionEquals(roleBO.isRolePresent(1, "Test", 10),new User(1, "Test", Role.role[0])));
	}
}

